<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <title></title>
</head>

<frameset cols="250px,*">
        <frame src="sellermenu.php" noresize="noresize" name="leftside"></frame>
        <frame src="sellerrightside.php" name="rightside"></frame>
        
</frameset>
</body>
</html>