<html>
<head>
		<title>Home Page</title>
		<link rel="stylesheet" type="text/css" href="rightsidecss.css">
		<style type="text/css">
			@import url('https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&display=swap');
		</style>
</head>
<body>
	<header>
		<nav>
			<h1 style=" font-size:26px;">MYSHOPEE</h1>
			<ul> <li><a href="Project.php">HOME</a></li>
				 <li><a href="about.php" >ABOUT</a></li>
				 <li><a href="login1.php">LOGIN</a></li>
                 <!--ABOUT PAGE...-->
			</ul>
		</nav>
	</header>
	<div class="divider">
	</div>
        <p class="para" style="font-family:'Dancing Script', cursive;">MyShopee is “Shop Management System Web Application”. It will be complete business solution for Small business running shops like: Fast Food Shop, Soda Shop, Barber Shop, etc. Who sells amount of products; nearly thirty to forty products in range.<br><br>It will help owners for making effective decisions; whose focus on timely supervision and success of business. <br><br>It allows to add products and manage their sells with effective report generation; all together it will give great support to small individual shop owners for make correct decision.</p>
        <img src="food1.jpg" width="210px" height="210px" style="margin-left:150px;margin-top:50px;border:2px solid white;border-radius: 5px;">
        <img src="food3.jpg" width="210px" height="210px" style="margin-left:100px;margin-top:50px;border:2px solid white;border-radius: 5px;">
        <img src="food8.jpg" width="210px" height="210px" style="margin-left:100px;margin-top:50px;border:2px solid white;border-radius: 5px;">
        <img src="home.jpg" width="210px" height="210px" style="margin-left:100px;margin-top:50px;border:2px solid white;border-radius: 5px;">
</body>
</html>