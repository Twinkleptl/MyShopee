<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
	<?php
		setcookie("USER","");   
	    setcookie("USERTYPE","");
        echo ("<script language=\"javascript\">window.open(\"project.php\",\"_top\"); </script>");
    
    ?>
</body>
</html>