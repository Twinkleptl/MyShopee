<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>

<frameset cols="250px,*">
	<frame src="adminmenu.php" noresize="noresize" name="leftside"></frame>
	<frame src="adminrightside.php" name="rightside"></frame>
	
</frameset>
</body>
</html>