<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
<link rel="stylesheet" type="text/css" href="menucss.css">
</head>
<body>
	<nav class="mainmenu">
		<ul>
		<li><a href="home">Home</a></li>
        <li><a href="home">Create</a>
        	<ul>
        	<li><a href="addproduct.php" target="rightside">Product</a></li>
                <li><a href="addseller.php" target="rightside">Seller</a></li>
        	</ul></li>
        <li><a href="home">Edit</a>
        	<ul>
        	<li><a href="showproduct.php" target="rightside">Product</a></li>
                <li><a href="showsellers.php" target="rightside">seller details</a></li>
        	</ul>
        </li>

        <li><a href="home">reports</a>
        	<ul>
        	<li><a href="showproductrep.php" target="rightside">products</a></li>
                <li><a href="showsellerrep.php" target="rightside">sellers</a></li>
                <li><a href="repselling.php" target="rightside">seller's selling</a></li>
                <li><a href="repprodselling.php" target="rightside">product selling</a></li>
        	</ul>
        </li>
        <li><a href="home">validity</a>
        	<ul>
        	<li><a href="checkvalidity.php" target="rightside">check status</a></li>
        	</ul>
        </li>
        <li><a href="home">Password</a>
        <ul>
                <li><a href="changepassword.php" target="rightside">Change</a></li>
       </ul></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
	</nav>

</body>
</html>