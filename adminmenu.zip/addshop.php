<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet" type="text/css" href="rightsidecss.css">
</head>
<body>
	<div class="box" style="height:860px;margin-top:100px;">
		<h2 style="color:green;">ADD SHOP</h2>
		<form action="saveaddshop.php" method="post">
			<input type="text" name="shopname" placeholder="Enter Shop Name" required="">
			<input type="text" name="address" placeholder="Enter Shop Address" required="">
			<input type="text" name="city" placeholder="Enter City" required="">
			<input type="text" name="pincode" placeholder="Enter Pincode" required="">
			<input type="text" name="state" placeholder="Enter State" required="">
			<input type="text" name="country" placeholder="Enter Country" required="">
			<input type="text" name="mobile1" placeholder="Enter Mobile No1" required="">
			<input type="text" name="mobile2" placeholder="Enter Mobile No2" required="">
			<input type="text" name="gstno" placeholder="Enter GSTNO" required="">
			<b><input type="submit" value="CREATE SHOP"></b>
		</form>
	</div>

</body>
</html>
<link rel="stylesheet" type="text/css" href="projectcss.css">