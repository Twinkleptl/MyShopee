<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet" type="text/css" href="rightsidecss.css">
</head>

<body>
<div class="box" style="height:370px">
<form action="saveproduct.php" method="post">
<h2 style="color:green;">ADD PRODUCT</h2>
  
<input type="text" name="pname" placeholder="Enter Product Name" required="">
<input type="text" name="pprice" placeholder="Enter Product Unit Price" required="">



<input type="submit" name="" value="CREATE PRODUCT"style="margin-bottom:10px;">
</form>
</div>
</body>
</html>