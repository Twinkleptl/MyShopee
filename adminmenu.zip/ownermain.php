<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>


<frameset cols="250px,*">
	<frame src="ownermenu.php" noresize="noresize" name="leftside"></frame>
	<frame src="ownerrightside.php" name="rightside"></frame>
	
</frameset>
</body>
</html>