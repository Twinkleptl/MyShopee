<html>
<head>
		<title>Home Page</title>
		<link rel="stylesheet" type="text/css" href="rightsidecss.css">
		<style>
@import url('https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&display=swap');
      </style>
</head>
<body>
	<header>
		<nav>
			<h1 style=" font-size:26px;">MYSHOPEE</h1>
			<ul> <li><a href="Project.php">HOME</a></li>
				 <li><a href="about.php">ABOUT</a></li>
				 <li><a href="login1.php">LOGIN</a></li>
			</ul>
		</nav>
	</header>
	<div class="divider">
	</div>
	<div class="image">
	<img src="Image4.jpg" style="height:300px; width:400px;">
    <p style="font-family: 'Dancing Script', cursive;">MyShopee is “Shop Management System Web Application”. It will be complete business solution for Small business running shops like: Fast Food Shop, Soda Shop, Barber Shop, etc. Who sells amount of products; nearly thirty to forty products in range.<br><BR> It will help owners for making effective decisions; whose focus on timely supervision and success of business.<br><BR>
 It allows to add products and manage their sells with effective report generation; all together it will give great support to small individual shop owners for make correct decision.</p>
   </div>
</body>
</html>