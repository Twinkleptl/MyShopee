<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
<link rel="stylesheet" type="text/css" href="menucss.css">
</head>
<body background="d.jpg">
	<nav class="mainmenu">
	<ul>
	       <li><a href="page1.php" target="rightside">Home</a></li>
              <li><a href="home">create</a>
                 <ul>
        	   <li><a href="addshop.php" target="rightside">Shop</a></li>
                 <li><a href="addowner.php" target="rightside">owner</a></li>
        	   </ul></li>
        <li><a href="home">Edit</a>
        	<ul>
        	  <li><a href="showshops.php" target="rightside">Shop Details</a></li>
                <li><a href="showvalidity.php" target="rightside">Validity</a></li>
                <li><a href="showusers.php" target="rightside">Owner & Seller</a></li>
        	</ul>
        </li>

        <li><a href="home">Report</a>
        <ul>
                <li><a href="showshoprep.php" target="rightside">Shops</a></li>
                <li><a href="showvalidityrep.php" target="rightside" >validity</a></li>
        </ul></li>
        <li><a href="home">Password</a>
        <ul>
                <li><a href="changepassword.php" target="rightside">Change</a></li>
       </ul></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
	</nav>

</body>
</html>