<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
<link rel="stylesheet" type="text/css" href="menucss.css">
</head>
<body>
	<nav class="mainmenu">
	<ul>
	       <li><a href="placeorder.php"target="rightside">Home</a></li>
        <!--<li><a href="home">Edit</a>
        	<ul>
        	  <li><a href="home">order</a></li>
        	</ul>
        </li>-->

        <li><a href="home">Report</a>
        <ul>
                <li><a href="dailyrep1.php"target="rightside">day</a></li>
                <li><a href="daterangerep1.php"target="rightside">date-range</a></li>
        </ul></li>
        <li><a href="home">Password</a>
        <ul>
                <li><a href="changepassword.php" target="rightside">Change</a></li>
       </ul></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
	</nav>

</body>
</html>